// Display current time in footer
document.addEventListener('DOMContentLoaded', () => {
  const timeEl = document.getElementById('current-time');

  if (timeEl) {
    function updateTime() {
      const now = new Date();
      // shows date + time in local format
      timeEl.textContent = now.toLocaleString();
    }

    updateTime(); // run once immediately
    setInterval(updateTime, 1000); // update every second
  }
});
