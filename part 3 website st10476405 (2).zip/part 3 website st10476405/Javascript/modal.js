document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('promoModal');
  const openBtn = document.getElementById('promoBtn');
  const closeBtn = modal.querySelector('.modal-close');

  openBtn.addEventListener('click', () => {
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
  });

  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
  });

  modal.addEventListener('click', e => {
    if (e.target === modal) {
      modal.style.display = 'none';
    }
  });
});
