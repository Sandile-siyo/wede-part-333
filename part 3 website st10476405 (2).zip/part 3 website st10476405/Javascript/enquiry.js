// ✅ Get references to form and output areas
const form = document.getElementById('enquiryForm');
const errorsBox = document.getElementById('enquiryErrors');
const resultBox = document.getElementById('enquiryResult');

// ✅ Validation function
function validateForm() {
  errorsBox.innerHTML = '';
  const errors = [];

  // Get form fields
  const name = document.getElementById('name');
  const email = document.getElementById('email');
  const phone = document.getElementById('phone');
  const topic = document.getElementById('topic');
  const date = document.getElementById('date');
  const message = document.getElementById('message');

  // Name validation
  if (!name.value || name.value.length < 2) {
    errors.push('Name must be at least 2 characters.');
  }

  // Email validation
  if (!email.validity.valid) {
    errors.push('Please enter a valid email address.');
  }

  // Phone validation (strict 10 digits)
  if (!/^[0-9]{10}$/.test(phone.value)) {
    errors.push('Phone number must be exactly 10 digits, e.g. 0641234567.');
  }

  // Topic validation
  if (!topic.value) {
    errors.push('Please select an enquiry type.');
  }

  // Date validation
  if (!date.value) {
    errors.push('Please choose a date.');
  }

  // Message validation
  if (!message.value || message.value.length < 10) {
    errors.push('Message must be at least 10 characters.');
  }

  // Show errors if any
  if (errors.length) {
    errorsBox.innerHTML = errors.map(e => `<div>• ${e}</div>`).join('');
    return false;
  }
  return true;
}

// ✅ Estimate cost based on service
function estimateCost(serviceName) {
  const prices = {
    'Classic Fade': 120,
    'Cut and Dye': 250,
    'Premium Cut and Facewash': 300
  };
  return prices[serviceName] || 'Varies';
}

// ✅ Handle form submission
form.addEventListener('submit', e => {
  e.preventDefault(); // Stop default form submission
  resultBox.innerHTML = ''; // Clear previous result

  // Run validation
  if (!validateForm()) return;

  // Get values
  const service = document.getElementById('service').value;
  const date = document.getElementById('date').value;
  const topic = document.getElementById('topic').value;

  // Build response
  const cost = service ? `Estimated cost: R${estimateCost(service)}.` : 'Cost will be confirmed based on your enquiry.';
  const availability = 'We have availability on your selected date.';
  resultBox.innerHTML = `
    <div style="background:#222; padding:12px; border-radius:8px;">
      <p><strong>Enquiry type:</strong> ${topic}</p>
      <p><strong>Date:</strong> ${date}</p>
      <p>${availability}</p>
      <p>${cost}</p>
      <p>We’ll contact you shortly via email/phone to confirm details.</p>
    </div>
  `;
});
