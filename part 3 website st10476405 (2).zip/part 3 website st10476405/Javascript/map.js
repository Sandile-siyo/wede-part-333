document.addEventListener('DOMContentLoaded', () => {
  // Coordinates for Randfontein, Johannesburg
  const lat = -26.1760;
  const lng = 27.5480;

  // Initialize map
  const map = L.map('map').setView([lat, lng], 14);

  // Add OpenStreetMap tiles
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);

  // Add marker for the barber shop
  L.marker([lat, lng]).addTo(map)
    .bindPopup('Ghetto Fabulous Barber Shop')
    .openPopup();
});
