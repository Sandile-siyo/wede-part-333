📁 Website/
├── 📄 index.html              🟨 Homepage with services, FAQ, and promotion modal
├── 📄 about-us.html           🟨 About Us page with shop story and values
├── 📄 contact-us.html         🟨 Contact page with enquiry form and map
├── 📄 find-us.html            🟨 Location page with interactive Leaflet map
├── 📄 price-list.html         🟨 Service pricing with styled image
├── 📄 enquiry.html            🟨 Form page with strict validation

📁 CSS/
├── 📄 style.css               🟨 Main stylesheet for layout, colors, and responsiveness
├── 📄 about-us.css            🟨 Page-specific styles (optional)
├── 📄 contact-us.css          🟨 Page-specific styles (optional)
├── 📄 find-us.css             🟨 Dark theme map styling
├── 📄 price-list.css          🟨 Image styling and layout
├── 📄 enquiry.css             🟨 Form styling and validation feedback

📁 Javascript/
├── 📄 website.js              🟨 Time display and general interactivity
├── 📄 accordion.js            🟨 FAQ toggle logic
├── 📄 modal.js                🟨 Promotion popup logic
├── 📄 map.js                  🟨 Leaflet map initialization
├── 📄 aboutus.js              🟨 Optional enhancements for About Us

📁 images/
├── 📄 G.jpeg                  🟨 Logo
├── 📄 ss.jpeg                 🟨 Classic Fade image
├── 📄 SMS.jpeg                🟨 Cut and Dye image
├── 📄 K.jpeg                  🟨 Premium Cut image
├── 📄 TMSS.jpeg               🟨 Price list image
├── 📄 SSS.jpg                 🟨 Background image
